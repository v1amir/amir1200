# Installing amir1200 on Windows 11 (for beginners)

You will build the program once on your own PC. It takes about 10 minutes. No administrator rights are needed
for amir1200 itself (the .NET installer may ask once).

## 1. What you need
- Windows 11 (any current version; 24H2 is supported in the code but untested - see Troubleshooting).
- Internet for the first build (to download packages).
- **.NET 10 SDK** (free, from Microsoft).
- **WebView2 Runtime** - already included with Windows 11. The checker below confirms it.

## 2. Install the .NET 10 SDK
1. Open https://dotnet.microsoft.com/download/dotnet/10.0
2. Under **SDK**, download the **Windows x64 installer** (use Arm64 only if your PC is ARM).
3. Run it and click through. Then **close and reopen PowerShell** (next step).

## 3. Open PowerShell in the amir1200 folder
1. Unzip the amir1200 folder somewhere simple, for example `C:\amir1200` (avoid very long paths).
2. Open the folder in File Explorer, click the address bar, type `powershell` and press Enter.
   A blue window opens already inside the folder. (These are **PowerShell** commands.)

## 4. Check your PC
```powershell
dotnet --version
.\build\Verify-amir1200.ps1
```
`dotnet --version` must print 10.x. If PowerShell says scripts are blocked, run this once for this window only, then retry:
```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass
```

## 5. Build
```powershell
.\build\build.ps1 -Shortcut
```
It runs the tests, then builds into `dist\amir1200`. At the end it prints the path of `amir1200.exe` and
creates a desktop shortcut (because of `-Shortcut`). Use `-SkipTests` to skip tests, `-Arm64` for ARM PCs.

## 6. Start it
Double-click the **amir1200** desktop shortcut, or `Start-amir1200.bat`, or `dist\amir1200\amir1200.exe`.
To stop it: right-click the amir1200 icon in the tray (bottom-right, maybe under the ^ arrow) > **Exit**.

## 7. Optional: start with Windows
Open amir1200 > **Settings** > tick *Start amir1200 when I sign in to Windows*. Untick it to undo.
It never starts with Windows unless you tick this.

## 8. Uninstall
Exit amir1200 from the tray, untick the startup option, delete the folder. To remove settings and logs too,
delete `%LocalAppData%\amir1200` (paste that into the Explorer address bar).

## If the build fails
See `docs/TROUBLESHOOTING.md`. Copy the **first** red error line when asking for help.
