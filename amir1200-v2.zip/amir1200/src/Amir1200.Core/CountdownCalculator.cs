using System.Globalization;

namespace Amir1200.Core;

public readonly record struct Remaining(long TotalSeconds, int Days, int Hours, int Minutes, int Seconds, bool IsReleased);

public static class CountdownCalculator
{
    public const string Format = "yyyy-MM-dd'T'HH:mm";

    /// <summary>Converts a wall-clock time in a zone to an absolute instant. Handles DST gaps and overlaps.</summary>
    public static bool TryGetTargetInstant(string? targetLocal, string? timeZoneId, out DateTimeOffset instant, out string? error)
    {
        instant = default;
        error = null;

        if (!DateTime.TryParseExact(targetLocal, Format, CultureInfo.InvariantCulture, DateTimeStyles.None, out var wall))
        {
            error = "The date and time are not valid. Use the format yyyy-MM-ddTHH:mm.";
            return false;
        }
        if (wall.Year < 2000 || wall.Year > 2100)
        {
            error = "The year must be between 2000 and 2100.";
            return false;
        }

        TimeZoneInfo tz;
        if (string.IsNullOrWhiteSpace(timeZoneId) || timeZoneId.Equals("local", StringComparison.OrdinalIgnoreCase))
        {
            tz = TimeZoneInfo.Local;
        }
        else
        {
            try { tz = TimeZoneInfo.FindSystemTimeZoneById(timeZoneId); }
            catch (Exception ex) when (ex is TimeZoneNotFoundException or InvalidTimeZoneException)
            {
                error = $"Time zone '{timeZoneId}' was not found on this PC.";
                return false;
            }
        }

        wall = DateTime.SpecifyKind(wall, DateTimeKind.Unspecified);
        if (tz.IsInvalidTime(wall)) wall = wall.AddHours(1); // spring-forward gap: move to the first valid time

        TimeSpan offset = tz.IsAmbiguousTime(wall)
            ? tz.GetAmbiguousTimeOffsets(wall).Max() // fall-back overlap: first occurrence
            : tz.GetUtcOffset(wall);

        instant = new DateTimeOffset(wall, offset);
        return true;
    }

    /// <summary>Never returns negative values. Rounds up so the display reaches zero exactly at the target.</summary>
    public static Remaining Compute(DateTimeOffset target, DateTimeOffset now)
    {
        var diff = target - now;
        if (diff <= TimeSpan.Zero) return new Remaining(0, 0, 0, 0, 0, true);

        long total = (long)Math.Ceiling(diff.TotalSeconds);
        return new Remaining(
            total,
            (int)(total / 86400),
            (int)(total % 86400 / 3600),
            (int)(total % 3600 / 60),
            (int)(total % 60),
            false);
    }
}
