namespace Amir1200.Core;

/// <summary>Decides which image comes next. Contains no timers or UI, so it is fully unit-testable.</summary>
public sealed class SlideshowEngine
{
    private readonly Random _rng;
    private List<string> _items = new();
    private List<int> _order = new();
    private int _pos = -1;

    public SlideshowEngine(int? seed = null) => _rng = seed is null ? new Random() : new Random(seed.Value);

    public bool Shuffle { get; set; }
    public bool Repeat { get; set; } = true;
    public int Count => _items.Count;
    public bool Finished { get; private set; }

    public string? Current => _pos >= 0 && _pos < _order.Count ? _items[_order[_pos]] : null;

    /// <summary>Replaces the image list. Keeps the current image selected when it is still present.</summary>
    public void SetItems(IEnumerable<string> paths)
    {
        var keep = Current;
        _items = paths.Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        Finished = false;
        Rebuild(keep);
    }

    public void Rebuild(string? keepCurrent = null)
    {
        _order = Enumerable.Range(0, _items.Count).ToList();
        if (Shuffle) ShuffleOrder(_order);

        if (_items.Count == 0) { _pos = -1; return; }

        if (keepCurrent is not null)
        {
            int idx = _items.FindIndex(p => p.Equals(keepCurrent, StringComparison.OrdinalIgnoreCase));
            if (idx >= 0)
            {
                int at = _order.IndexOf(idx);
                if (Shuffle)
                {
                    _order.RemoveAt(at);
                    _order.Insert(0, idx); // current image stays first in the new shuffled order
                    _pos = 0;
                }
                else
                {
                    _pos = at; // sequential order is untouched
                }
                return;
            }
        }
        _pos = 0;
    }

    /// <summary>Returns the next image, or null when the list is empty or a non-repeating show has ended.</summary>
    public string? MoveNext()
    {
        if (_items.Count == 0) return null;
        if (_pos + 1 < _order.Count) { _pos++; return Current; }

        if (!Repeat) { Finished = true; return null; }

        int last = _order[_pos];
        if (Shuffle)
        {
            ShuffleOrder(_order);
            if (_order.Count > 1 && _order[0] == last) // never show the same image twice in a row
                (_order[0], _order[1]) = (_order[1], _order[0]);
        }
        _pos = 0;
        return Current;
    }

    public string? MovePrevious()
    {
        if (_items.Count == 0) return null;
        Finished = false;
        if (_pos - 1 >= 0) _pos--;
        else _pos = Repeat ? _order.Count - 1 : 0;
        return Current;
    }

    /// <summary>The image that will follow Current, for preloading. Null when unknown (shuffle wrap-around).</summary>
    public string? PeekNext()
    {
        if (_items.Count == 0) return null;
        if (_pos + 1 < _order.Count) return _items[_order[_pos + 1]];
        return Repeat && !Shuffle ? _items[_order[0]] : null;
    }

    private void ShuffleOrder(List<int> list)
    {
        for (int i = list.Count - 1; i > 0; i--)
        {
            int j = _rng.Next(i + 1);
            (list[i], list[j]) = (list[j], list[i]);
        }
    }
}
