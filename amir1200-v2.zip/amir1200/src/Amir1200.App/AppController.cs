using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using Amir1200.App.Services;
using Amir1200.App.Wallpaper;
using Amir1200.Core;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace Amir1200.App;

/// <summary>The single place that connects settings, the wallpaper windows, the tray and the control panel.</summary>
internal sealed class AppController : IDisposable
{
    private const int MaxFolderImages = 5000;
    private const string ImageFilter = "Images|*.jpg;*.jpeg;*.png;*.webp;*.bmp|All files|*.*";
    private const string VideoFilter = "Video files|*.mp4;*.webm;*.mov;*.m4v;*.ogv|All files|*.*";

    private readonly SettingsStore _store = new(AppPaths.SettingsFile);
    private AppSettings _settings = new();
    private CoreWebView2Environment? _env;
    private WallpaperManager? _wallpaper;
    private TrayIcon? _tray;
    private MainWindow? _window;
    private string? _startupWarning;
    private bool _exiting;

    public async Task StartAsync(bool background)
    {
        _settings = _store.Load(out _startupWarning);
        if (_startupWarning is not null) Log.Warn(_startupWarning);
        try { _settings.Behavior.StartWithWindows = StartupService.IsEnabled(); }
        catch (Exception ex) when (ex is System.Security.SecurityException or UnauthorizedAccessException)
        {
            Log.Warn("Could not read the startup setting: " + ex.Message);
        }

        try
        {
            _ = CoreWebView2Environment.GetAvailableBrowserVersionString();
        }
        catch (WebView2RuntimeNotFoundException)
        {
            System.Windows.MessageBox.Show(
                "amir1200 needs the Microsoft Edge WebView2 Runtime, which was not found on this PC.\n\n" +
                "Install it from https://developer.microsoft.com/microsoft-edge/webview2/ (Evergreen Standalone Installer), then start amir1200 again.",
                "amir1200", System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Warning);
            Exit();
            return;
        }

        Directory.CreateDirectory(AppPaths.WebViewData);
        var options = new CoreWebView2EnvironmentOptions(
            additionalBrowserArguments: "--autoplay-policy=no-user-gesture-required --disable-features=CalculateNativeWinOcclusion");
        _env = await CoreWebView2Environment.CreateAsync(null, AppPaths.WebViewData, options);

        _wallpaper = new WallpaperManager(_env, () => _settings);
        _wallpaper.Notify += Notify;
        _wallpaper.StateChanged += OnWallpaperStateChanged;
        _wallpaper.Slideshow.SlideChanged += OnSlideForPanel;

        _tray = new TrayIcon();
        _tray.OpenRequested += () => _ = ShowMainWindowAsync();
        _tray.ExitRequested += Exit;
        _tray.ModeRequested += mode => _ = SetModeAsync(mode);
        _tray.NextImageRequested += () => _wallpaper?.Slideshow.Next();
        _tray.TogglePauseRequested += () =>
        {
            if (_wallpaper is null) return;
            _wallpaper.SetPause("user", !_wallpaper.PauseReasons.Contains("user"));
        };
        _tray.UpdateState(_settings.Mode, false);

        if (!background) await ShowMainWindowAsync();
        await _wallpaper.ApplyAsync(forceSlide: true); // resume the last wallpaper mode
    }

    public async Task ShowMainWindowAsync()
    {
        if (_exiting || _env is null) return;
        if (_window is not null)
        {
            if (_window.WindowState == System.Windows.WindowState.Minimized) _window.WindowState = System.Windows.WindowState.Normal;
            _window.Activate();
            return;
        }

        var window = new MainWindow();
        _window = window;
        window.MessageReceived += OnUiMessage;
        window.Closed += (_, _) =>
        {
            window.MessageReceived -= OnUiMessage;
            if (ReferenceEquals(_window, window)) _window = null; // the page and its WebView2 process are released here
            if (!_exiting && !_settings.Behavior.MinimizeToTray) Exit();
        };
        window.Show();
        try
        {
            await window.InitializeAsync(_env);
        }
        catch (Exception ex)
        {
            Log.Error("The control panel could not start", ex);
            System.Windows.MessageBox.Show("The amir1200 window could not start: " + ex.Message, "amir1200");
            window.Close();
        }
    }

    /* ---------- messages from the control panel ---------- */

    private async void OnUiMessage(string json)
    {
        try
        {
            using JsonDocument doc = JsonDocument.Parse(json);
            JsonElement root = doc.RootElement;
            string type = root.TryGetProperty("type", out JsonElement t) ? t.GetString() ?? string.Empty : string.Empty;
            await HandleUiMessageAsync(type, root);
        }
        catch (Exception ex)
        {
            // Boundary: one bad request must never take the app down.
            Log.Error("Handling a control panel request failed", ex);
            Notify("error", "Something went wrong: " + ex.Message);
        }
    }

    private async Task HandleUiMessageAsync(string type, JsonElement m)
    {
        if (_wallpaper is null) return;
        switch (type)
        {
            case "ready":
                SendState();
                if (_startupWarning is not null) { Notify("warn", _startupWarning); _startupWarning = null; }
                break;

            case "save":
                await SaveFromPanelAsync(m);
                break;

            case "setMode":
                if (Enum.TryParse(m.GetProperty("mode").GetString(), ignoreCase: true, out WallpaperMode mode))
                {
                    await SetModeAsync(mode);
                }
                break;

            case "pickVideo":
                await PickVideoAsync();
                break;

            case "addImages":
                await AddImagesAsync();
                break;

            case "addFolder":
                await AddFolderAsync();
                break;

            case "removeImage":
                GalleryOps.Remove(_settings.Gallery, m.GetProperty("path").GetString() ?? string.Empty);
                await GalleryChangedAsync();
                break;

            case "clearGallery":
                _settings.Gallery.Images.Clear();
                await GalleryChangedAsync();
                break;

            case "setIncluded":
                GalleryOps.SetIncluded(_settings.Gallery, m.GetProperty("path").GetString() ?? string.Empty, m.GetProperty("included").GetBoolean());
                await GalleryChangedAsync();
                break;

            case "moveImage":
                GalleryOps.Move(_settings.Gallery, m.GetProperty("from").GetInt32(), m.GetProperty("to").GetInt32());
                await GalleryChangedAsync();
                break;

            case "slideshow":
                RunSlideshowCommand(m.GetProperty("cmd").GetString());
                break;

            case "videoCmd":
                string? cmd = m.GetProperty("cmd").GetString();
                if (cmd is "pause" or "play" or "restart") _wallpaper.VideoCommand(cmd);
                break;

            case "resetSettings":
                await ResetAsync();
                break;

            case "restoreWallpaper":
                _settings.Mode = WallpaperMode.Off;
                SaveSettings();
                bool restored = _wallpaper.RestoreOriginal();
                Notify(restored ? "success" : "info",
                    restored ? "Your previous wallpaper was restored." : "amir1200 stopped. Windows shows your normal desktop background again.");
                SendState();
                break;

            case "openLogs":
                Directory.CreateDirectory(Log.Folder);
                Process.Start(new ProcessStartInfo("explorer.exe", "\"" + Log.Folder + "\"") { UseShellExecute = true });
                break;
        }
    }

    private async Task SaveFromPanelAsync(JsonElement m)
    {
        AppSettings? incoming = m.GetProperty("settings").Deserialize<AppSettings>(JsonDefaults.Options);
        if (incoming is null || _wallpaper is null) return;

        SettingsValidator.Normalize(incoming);
        // The host owns these; a stale copy in the page must never overwrite them.
        incoming.Mode = _settings.Mode;
        incoming.Video.Path = _settings.Video.Path;
        incoming.Gallery.Images = _settings.Gallery.Images;

        bool startupChanged = incoming.Behavior.StartWithWindows != _settings.Behavior.StartWithWindows;
        _settings = incoming;
        if (startupChanged)
        {
            try { StartupService.Set(_settings.Behavior.StartWithWindows); }
            catch (Exception ex) when (ex is InvalidOperationException or UnauthorizedAccessException or System.Security.SecurityException)
            {
                _settings.Behavior.StartWithWindows = !_settings.Behavior.StartWithWindows;
                Notify("error", "Windows startup could not be changed: " + ex.Message);
                SendState();
            }
        }
        SaveSettings();
        await _wallpaper.ApplyAsync();
        SendScene();
    }

    private async Task<bool> SetModeAsync(WallpaperMode mode)
    {
        if (_wallpaper is null) return false;

        if (mode == WallpaperMode.Video)
        {
            string? error = MediaFiles.ValidateVideo(_settings.Video.Path);
            if (error is not null) { Notify("error", error); SendState(); return false; }
            _wallpaper.ClearVideoFailure(); // choosing it again is an explicit retry
        }
        else if (mode == WallpaperMode.Gallery &&
                 !GalleryOps.IncludedPaths(_settings.Gallery).Any(File.Exists))
        {
            Notify("warn", "Add some screenshots to the gallery first.");
            return false;
        }

        _settings.Mode = mode;
        SaveSettings();
        await _wallpaper.ApplyAsync(forceSlide: mode == WallpaperMode.Gallery);
        SendState();
        return true;
    }

    private async Task PickVideoAsync()
    {
        var dialog = new OpenFileDialog { Title = "Choose a video for your wallpaper", Filter = VideoFilter, CheckFileExists = true };
        if (!ShowDialog(dialog)) return;

        string? error = MediaFiles.ValidateVideo(dialog.FileName);
        if (error is not null) { Notify("error", error); return; }

        _settings.Video.Path = dialog.FileName;
        _wallpaper?.ClearVideoFailure();
        SaveSettings();
        if (_settings.Mode == WallpaperMode.Video && _wallpaper is not null) await _wallpaper.ApplyAsync();
        else Notify("success", "Video selected. Press \"Set as wallpaper\" to use it.");
        SendState();
    }

    private async Task AddImagesAsync()
    {
        var dialog = new OpenFileDialog { Title = "Add GTA VI screenshots", Filter = ImageFilter, Multiselect = true, CheckFileExists = true };
        if (!ShowDialog(dialog)) return;

        int added = GalleryOps.AddRange(_settings.Gallery, dialog.FileNames);
        Notify(added > 0 ? "success" : "info", added > 0 ? $"Added {added} image(s)." : "Those images were already in the gallery.");
        await GalleryChangedAsync();
    }

    private async Task AddFolderAsync()
    {
        var dialog = new OpenFolderDialog { Title = "Choose a folder with GTA VI screenshots" };
        if (!ShowDialog(dialog)) return;

        string folder = dialog.FolderName;
        var found = await Task.Run(() => MediaFiles.EnumerateImages(folder, recursive: true));
        if (found.Count == 0) { Notify("warn", "No JPG, PNG, WebP or BMP images were found in that folder."); return; }

        bool capped = found.Count > MaxFolderImages;
        int added = GalleryOps.AddRange(_settings.Gallery, found.Take(MaxFolderImages));
        Notify(capped ? "warn" : "success", capped
            ? $"Added the first {MaxFolderImages} images (the folder has {found.Count})."
            : $"Added {added} image(s) from the folder.");
        await GalleryChangedAsync();
    }

    private bool ShowDialog(CommonDialog dialog) =>
        (_window is null ? dialog.ShowDialog() : dialog.ShowDialog(_window)) == true;

    private async Task GalleryChangedAsync()
    {
        SaveSettings();
        if (_settings.Mode == WallpaperMode.Gallery && _wallpaper is not null) await _wallpaper.ApplyAsync();
        SendState();
    }

    private void RunSlideshowCommand(string? cmd)
    {
        if (_wallpaper is null) return;
        switch (cmd)
        {
            case "next": _wallpaper.Slideshow.Next(); break;
            case "prev": _wallpaper.Slideshow.Previous(); break;
            case "toggle": _wallpaper.Slideshow.TogglePause(); break;
        }
        _window?.Post(SceneConfig.ToJson(new { type = "slideshowState", paused = _wallpaper.Slideshow.UserPaused }));
    }

    private async Task ResetAsync()
    {
        if (_wallpaper is null) return;
        try { StartupService.Set(false); }
        catch (Exception ex) when (ex is InvalidOperationException or UnauthorizedAccessException or System.Security.SecurityException)
        {
            Log.Warn("Could not remove the startup entry: " + ex.Message);
        }
        _settings = SettingsValidator.Normalize(new AppSettings());
        _wallpaper.ClearVideoFailure();
        SaveSettings();
        await _wallpaper.ApplyAsync();
        SendState();
        Notify("success", "All settings were reset to their defaults.");
    }

    /* ---------- state sent to the control panel ---------- */

    private void SendState()
    {
        if (_window is null || _wallpaper is null) return;
        MediaMapper? mapper = _window.Mapper;
        Func<string?, string?> urlFor = p => mapper?.UrlFor(p);

        var images = _settings.Gallery.Images.Select(i =>
        {
            string? url = urlFor(i.Path);
            return new { path = i.Path, name = Path.GetFileName(i.Path), url, included = i.Included, missing = url is null };
        }).ToList();

        _window.Post(SceneConfig.ToJson(new
        {
            type = "state",
            settings = _settings,
            scene = SceneConfig.Build(_settings, _wallpaper.EffectiveMode, urlFor),
            images,
            videoName = Path.GetFileName(_settings.Video.Path ?? string.Empty),
            videoError = VideoError(),
            status = BuildStatus(),
            version = typeof(AppController).Assembly.GetName().Version?.ToString(3) ?? "1.0.0",
            settingsPath = AppPaths.SettingsFile,
        }));
        _tray?.UpdateState(_settings.Mode, _wallpaper.PauseReasons.Contains("user"));
    }

    private void SendScene()
    {
        if (_window is null || _wallpaper is null) return;
        MediaMapper? mapper = _window.Mapper;
        Func<string?, string?> urlFor = p => mapper?.UrlFor(p);
        _window.Post(SceneConfig.ToJson(new
        {
            type = "scene",
            scene = SceneConfig.Build(_settings, _wallpaper.EffectiveMode, urlFor),
            status = BuildStatus(),
            videoError = VideoError(),
        }));
    }

    private string? VideoError()
    {
        if (_settings.Video.Path is null) return null;
        return MediaFiles.ValidateVideo(_settings.Video.Path)
               ?? (_settings.Mode == WallpaperMode.Video ? _wallpaper?.FallbackReason : null);
    }

    private object BuildStatus()
    {
        WallpaperManager w = _wallpaper!;
        WallpaperMode chosen = _settings.Mode;
        string modeName = JsonNamingPolicy.CamelCase.ConvertName(chosen.ToString());
        string level = string.Empty, shortText, text;

        if (chosen == WallpaperMode.Off || !w.IsRunning)
        {
            shortText = "Off";
            text = "No wallpaper is running. Your normal desktop background is shown.";
        }
        else
        {
            string what = chosen switch { WallpaperMode.Video => "Live video", WallpaperMode.Gallery => "Gallery", _ => "Countdown" };
            if (w.FallbackReason is not null)
            {
                level = "warn";
                shortText = what + " unavailable";
                text = w.FallbackReason + " The countdown is shown instead.";
            }
            else if (w.IsPaused)
            {
                level = "warn";
                shortText = "Paused";
                text = what + " is paused (" + string.Join(", ", w.PauseReasons.Select(PauseText)) + ").";
            }
            else
            {
                level = "live";
                shortText = what + " running";
                text = what + " wallpaper is running.";
                if (chosen == WallpaperMode.Gallery) text += $" {w.Slideshow.Count} image(s), changing every {_settings.Gallery.IntervalSeconds} s.";
                if (!w.DesktopIntegrated) text += " It could not be placed behind the desktop icons.";
            }
        }
        return new { mode = modeName, level, @short = shortText, text };
    }

    private static string PauseText(string reason) => reason switch
    {
        "lock" => "screen locked",
        "sleep" => "PC sleeping",
        "fullscreen" => "a full-screen app is open",
        "battery" => "on battery power",
        "user" => "paused by you",
        _ => reason,
    };

    private void OnWallpaperStateChanged()
    {
        SendScene();
        _tray?.UpdateState(_settings.Mode, _wallpaper?.PauseReasons.Contains("user") == true);
    }

    private void OnSlideForPanel(string path, string? next)
    {
        if (_window?.Mapper is null) return;
        string? url = _window.Mapper.UrlFor(path);
        if (url is null) return;
        _window.Post(SceneConfig.ToJson(new { type = "slide", url, preload = next is null ? null : _window.Mapper.UrlFor(next) }));
    }

    private void Notify(string level, string text)
    {
        if (_window is not null) _window.Post(SceneConfig.ToJson(new { type = "toast", level, text }));
        else if (level is "error" or "warn") _tray?.ShowBalloon(text, level == "error");
    }

    private void SaveSettings()
    {
        try { _store.Save(_settings); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Log.Error("Settings could not be saved", ex);
            Notify("error", "Settings could not be saved: " + ex.Message);
        }
    }

    public void Exit()
    {
        if (_exiting) return;
        _exiting = true;
        try { _store.Save(_settings); }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException) { Log.Warn("Final save failed: " + ex.Message); }
        Dispose();
        System.Windows.Application.Current.Shutdown();
    }

    public void Dispose()
    {
        _wallpaper?.Dispose();
        _wallpaper = null;
        _tray?.Dispose();
        _tray = null;
        _window?.Close();
        _window = null;
    }
}
