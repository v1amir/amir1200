using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Amir1200.App.Services;
using Microsoft.Web.WebView2.Core;

namespace Amir1200.App.Wallpaper;

/// <summary>
/// Lets a WebView2 read the user's own media files in place (no copying) by mapping each folder
/// to a private virtual host name. Only folders the user actually picked are ever mapped.
/// </summary>
internal sealed class MediaMapper
{
    private readonly CoreWebView2 _web;
    private readonly Dictionary<string, string> _hosts = new(StringComparer.OrdinalIgnoreCase);

    public MediaMapper(CoreWebView2 web) => _web = web;

    /// <summary>Returns an https URL for the file, or null when the file is missing or unreadable.</summary>
    public string? UrlFor(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return null;
        try
        {
            string full = Path.GetFullPath(path);
            if (!File.Exists(full)) return null;
            string? folder = Path.GetDirectoryName(full);
            if (folder is null) return null;

            if (!_hosts.TryGetValue(folder, out string? host))
            {
                byte[] hash = SHA256.HashData(Encoding.UTF8.GetBytes(folder.ToLowerInvariant()));
                host = "m" + Convert.ToHexString(hash)[..12].ToLowerInvariant() + ".amir1200";
                _web.SetVirtualHostNameToFolderMapping(host, folder, CoreWebView2HostResourceAccessKind.Allow);
                _hosts[folder] = host;
            }
            return "https://" + host + "/" + Uri.EscapeDataString(Path.GetFileName(full));
        }
        catch (Exception ex) when (ex is ArgumentException or NotSupportedException or PathTooLongException
                                      or IOException or UnauthorizedAccessException)
        {
            Log.Warn("Media path could not be mapped: " + ex.Message);
            return null;
        }
    }
}
