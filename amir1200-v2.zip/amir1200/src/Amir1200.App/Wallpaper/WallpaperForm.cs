using System;
using System.Drawing;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using Amir1200.App.Services;
using Microsoft.Web.WebView2.Core;
using WinFormsWebView2 = Microsoft.Web.WebView2.WinForms.WebView2;

namespace Amir1200.App.Wallpaper;

/// <summary>One borderless window per monitor that hosts the scene (video, slideshow and countdown) in WebView2.</summary>
internal sealed class WallpaperForm : Form
{
    private readonly WinFormsWebView2 _web = new() { Dock = DockStyle.Fill };
    private readonly TaskCompletionSource<bool> _ready = new(TaskCreationOptions.RunContinuationsAsynchronously);

    public WallpaperForm(Screen screen)
    {
        TargetScreen = screen;
        FormBorderStyle = FormBorderStyle.None;
        ShowInTaskbar = false;
        StartPosition = FormStartPosition.Manual;
        BackColor = Color.Black;
        // Start off-screen so nothing flashes before the window is attached to the desktop.
        Bounds = new Rectangle(-32000, -32000, screen.Bounds.Width, screen.Bounds.Height);
        Controls.Add(_web);
    }

    internal Screen TargetScreen { get; }
    private MediaMapper? _mapper;
    internal MediaMapper? Mapper => _mapper;
    internal bool AttachedToDesktop; // field on purpose: WinForms analyzer WFO1000 only checks properties

    public event Action<WallpaperForm, JsonElement>? SceneMessage;
    public event Action<WallpaperForm>? WebProcessFailed;

    protected override bool ShowWithoutActivation => true;

    protected override CreateParams CreateParams
    {
        get
        {
            CreateParams cp = base.CreateParams;
            cp.ExStyle |= 0x00000080 | 0x08000000; // WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE
            return cp;
        }
    }

    public async Task InitializeAsync(CoreWebView2Environment env)
    {
        _web.DefaultBackgroundColor = Color.Black;
        await _web.EnsureCoreWebView2Async(env);
        CoreWebView2 core = _web.CoreWebView2;

        core.SetVirtualHostNameToFolderMapping("scene.amir1200", AppPaths.SceneDir, CoreWebView2HostResourceAccessKind.Allow);
        core.Settings.AreDefaultContextMenusEnabled = false;
        core.Settings.AreDevToolsEnabled = false;
        core.Settings.IsStatusBarEnabled = false;
        core.Settings.IsZoomControlEnabled = false;
        core.Settings.AreBrowserAcceleratorKeysEnabled = false;
        core.Settings.IsPasswordAutosaveEnabled = false;
        core.Settings.IsGeneralAutofillEnabled = false;

        _mapper = new MediaMapper(core);
        core.WebMessageReceived += OnWebMessage;
        core.ProcessFailed += (_, e) =>
        {
            Log.Error("WebView2 process failed: " + e.ProcessFailedKind);
            WebProcessFailed?.Invoke(this);
        };
        core.Navigate("https://scene.amir1200/scene.html");
    }

    public async Task<bool> WaitUntilReadyAsync(TimeSpan timeout)
    {
        Task finished = await Task.WhenAny(_ready.Task, Task.Delay(timeout));
        return finished == _ready.Task;
    }

    public void Post(string json)
    {
        if (IsDisposed || _web.CoreWebView2 is null) return;
        try { _web.CoreWebView2.PostWebMessageAsJson(json); }
        catch (InvalidOperationException ex) { Log.Warn("Posting to the scene failed: " + ex.Message); }
    }

    private void OnWebMessage(object? sender, CoreWebView2WebMessageReceivedEventArgs e)
    {
        try
        {
            using JsonDocument doc = JsonDocument.Parse(e.WebMessageAsJson);
            JsonElement root = doc.RootElement.Clone();
            if (root.TryGetProperty("type", out JsonElement type) && type.GetString() == "sceneReady")
            {
                _ready.TrySetResult(true);
            }
            SceneMessage?.Invoke(this, root);
        }
        catch (JsonException ex)
        {
            Log.Warn("Unreadable scene message: " + ex.Message);
        }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _ready.TrySetResult(false);
            try { _web.CoreWebView2?.Navigate("about:blank"); } catch (InvalidOperationException) { /* already closing */ }
        }
        base.Dispose(disposing);
    }
}
