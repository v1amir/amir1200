using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Threading;
using Amir1200.App.Services;
using Amir1200.Core;
using Microsoft.Web.WebView2.Core;
using Microsoft.Win32;

namespace Amir1200.App.Wallpaper;

/// <summary>
/// Owns the wallpaper windows (one per monitor). Creates them only while a wallpaper mode is active
/// and disposes them completely when it stops, so nothing keeps playing in the background.
/// </summary>
internal sealed class WallpaperManager : IDisposable
{
    private readonly CoreWebView2Environment _env;
    private readonly Func<AppSettings> _getSettings;
    private readonly Dispatcher _ui = Dispatcher.CurrentDispatcher;
    private readonly List<WallpaperForm> _forms = new();
    private readonly HashSet<string> _pauseReasons = new();
    private readonly DispatcherTimer _fullscreenTimer = new() { Interval = TimeSpan.FromSeconds(3) };
    private readonly DispatcherTimer _displayTimer = new() { Interval = TimeSpan.FromMilliseconds(1500) };

    private bool _busy;
    private bool _pending;
    private bool _forceSlide;
    private bool _disposed;
    private string? _failedVideo;
    private string? _failedVideoMessage;
    private WallpaperMode _effective = WallpaperMode.Off;

    public WallpaperManager(CoreWebView2Environment env, Func<AppSettings> getSettings)
    {
        _env = env;
        _getSettings = getSettings;
        Slideshow.SlideChanged += OnSlide;
        _fullscreenTimer.Tick += OnFullscreenTick;
        _displayTimer.Tick += OnDisplayTimer;
        SystemEvents.DisplaySettingsChanged += OnDisplaySettingsChanged;
        SystemEvents.SessionSwitch += OnSessionSwitch;
        SystemEvents.PowerModeChanged += OnPowerModeChanged;
    }

    public SlideshowController Slideshow { get; } = new();
    public event Action<string, string>? Notify;
    public event Action? StateChanged;

    public WallpaperMode EffectiveMode => _effective;
    public bool IsRunning => _forms.Count > 0;
    public bool IsPaused => _pauseReasons.Count > 0;
    public IReadOnlyCollection<string> PauseReasons => _pauseReasons;
    public string? FallbackReason { get; private set; }
    public bool DesktopIntegrated { get; private set; }
    public string IntegrationDetail { get; private set; } = string.Empty;

    public void ClearVideoFailure()
    {
        _failedVideo = null;
        _failedVideoMessage = null;
    }

    /// <summary>Brings the running wallpaper in line with the saved settings. Safe to call repeatedly.</summary>
    public async Task ApplyAsync(bool forceSlide = false)
    {
        if (_disposed) return;
        if (forceSlide) _forceSlide = true;
        if (_busy) { _pending = true; return; }

        _busy = true;
        try
        {
            do
            {
                _pending = false;
                await ApplyCoreAsync();
            }
            while (_pending && !_disposed);
        }
        catch (Exception ex)
        {
            // Boundary for everything that can go wrong while talking to the shell and WebView2.
            Log.Error("Applying the wallpaper failed", ex);
            CloseForms();
            _effective = WallpaperMode.Off;
            Notify?.Invoke("error", "The wallpaper could not be started: " + ex.Message);
        }
        finally
        {
            _busy = false;
            StateChanged?.Invoke();
        }
    }

    private async Task ApplyCoreAsync()
    {
        AppSettings s = _getSettings();
        WallpaperMode previous = _effective;
        FallbackReason = null;

        if (s.Mode == WallpaperMode.Off)
        {
            CloseForms();
            Slideshow.Stop();
            _effective = WallpaperMode.Off;
            UpdateTimers(s);
            return;
        }

        RememberOriginalWallpaper();

        WallpaperMode effective = s.Mode;
        if (s.Mode == WallpaperMode.Video)
        {
            string? error = MediaFiles.ValidateVideo(s.Video.Path);
            if (error is null && string.Equals(_failedVideo, s.Video.Path, StringComparison.OrdinalIgnoreCase))
            {
                error = _failedVideoMessage ?? "This video could not be played.";
            }
            if (error is not null)
            {
                FallbackReason = error;
                effective = WallpaperMode.CountdownOnly;
                Notify?.Invoke("error", error + " Showing the countdown instead.");
            }
        }
        else if (s.Mode == WallpaperMode.Gallery)
        {
            Slideshow.Configure(s.Gallery);
            if (Slideshow.Count == 0)
            {
                FallbackReason = "The gallery has no usable images.";
                effective = WallpaperMode.CountdownOnly;
                Notify?.Invoke("warn", "The gallery has no usable images. Showing the countdown instead.");
            }
        }

        bool created = await EnsureFormsAsync(s);

        foreach (WallpaperForm form in _forms)
        {
            Func<string?, string?> urlFor;
            if (form.Mapper is null) urlFor = _ => null;
            else urlFor = form.Mapper.UrlFor;
            form.Post(SceneConfig.Message("config", SceneConfig.Build(s, effective, urlFor)));
        }
        _effective = effective;
        PushPause();

        if (effective == WallpaperMode.Gallery)
        {
            Slideshow.Start(previous != WallpaperMode.Gallery || created || _forceSlide);
        }
        else
        {
            Slideshow.Stop();
        }
        _forceSlide = false;
        UpdateTimers(s);
    }

    private async Task<bool> EnsureFormsAsync(AppSettings s)
    {
        Screen[] screens = s.Behavior.PrimaryMonitorOnly
            ? new[] { Screen.PrimaryScreen ?? Screen.AllScreens[0] }
            : Screen.AllScreens;

        bool same = _forms.Count == screens.Length && _forms.All(f =>
            !f.IsDisposed && screens.Any(sc => sc.DeviceName == f.TargetScreen.DeviceName && sc.Bounds == f.TargetScreen.Bounds));
        if (same) return false;

        CloseForms();
        foreach (Screen screen in screens)
        {
            WallpaperForm? form = await CreateFormAsync(screen);
            if (form is not null) _forms.Add(form);
        }
        if (_forms.Count == 0) throw new InvalidOperationException("No wallpaper window could be created.");

        DesktopIntegrated = _forms.All(f => f.AttachedToDesktop);
        if (!DesktopIntegrated)
        {
            Notify?.Invoke("warn",
                "Windows did not allow placing the wallpaper behind the desktop icons, so it is shown as a window at the bottom. " +
                "Icons may be hidden. Use the tray menu > Off to stop it.");
        }
        return true;
    }

    private async Task<WallpaperForm?> CreateFormAsync(Screen screen)
    {
        var form = new WallpaperForm(screen);
        try
        {
            form.SceneMessage += OnSceneMessage;
            form.WebProcessFailed += OnWebProcessFailed;
            form.Show();

            AttachMethod method = DesktopHost.Attach(form.Handle, screen.Bounds, out string detail);
            if (method == AttachMethod.None) DesktopHost.PlaceAtBottom(form.Handle, screen.Bounds);
            form.AttachedToDesktop = method != AttachMethod.None;
            IntegrationDetail = detail;
            Log.Info($"Monitor {screen.DeviceName} {screen.Bounds}: {detail}");

            await form.InitializeAsync(_env);
            if (!await form.WaitUntilReadyAsync(TimeSpan.FromSeconds(15)))
            {
                Log.Warn("The wallpaper scene did not report ready within 15 seconds.");
                Notify?.Invoke("error", "The wallpaper page did not start on one monitor. See the log for details.");
                form.Dispose();
                return null;
            }
            return form;
        }
        catch
        {
            form.Dispose();
            throw;
        }
    }

    private void CloseForms()
    {
        foreach (WallpaperForm form in _forms)
        {
            form.SceneMessage -= OnSceneMessage;
            form.WebProcessFailed -= OnWebProcessFailed;
            try { form.Close(); }
            catch (InvalidOperationException ex) { Log.Warn("Closing a wallpaper window: " + ex.Message); }
            finally { form.Dispose(); }
        }
        _forms.Clear();
        DesktopIntegrated = false;
        _pauseReasons.Remove("fullscreen");
    }

    /* ---------- messages from the scene ---------- */

    private void OnSceneMessage(WallpaperForm form, JsonElement m)
    {
        string type = m.TryGetProperty("type", out JsonElement t) ? t.GetString() ?? string.Empty : string.Empty;
        string message = m.TryGetProperty("message", out JsonElement msg) ? msg.GetString() ?? string.Empty : string.Empty;
        string kind = m.TryGetProperty("kind", out JsonElement k) ? k.GetString() ?? string.Empty : string.Empty;

        switch (type)
        {
            case "sceneError" when kind == "video":
                Log.Warn("Video error: " + message);
                _failedVideo = _getSettings().Video.Path;
                _failedVideoMessage = message;
                _ = ApplyAsync();
                break;
            case "sceneError" when kind == "image":
                Log.Warn("Image error: " + message);
                Slideshow.ReportBadImage();
                break;
            case "sceneWarning":
                Notify?.Invoke("warn", message);
                break;
            case "slideShown":
                Slideshow.ReportShown();
                break;
        }
    }

    private void OnWebProcessFailed(WallpaperForm form)
    {
        Notify?.Invoke("warn", "The wallpaper engine restarted after a problem. Re-applying.");
        _ = ApplyAsync(forceSlide: true);
    }

    private void OnSlide(string path, string? next)
    {
        bool reportedMissing = false;
        foreach (WallpaperForm form in _forms)
        {
            string? url = form.Mapper?.UrlFor(path);
            if (url is null)
            {
                if (!reportedMissing) { reportedMissing = true; Slideshow.ReportBadImage(); }
                continue;
            }
            string? preload = next is null ? null : form.Mapper?.UrlFor(next);
            form.Post(SceneConfig.ToJson(new { type = "slide", url, preload }));
        }
    }

    public void VideoCommand(string cmd)
    {
        string json = SceneConfig.ToJson(new { type = "video", cmd });
        foreach (WallpaperForm form in _forms) form.Post(json);
    }

    /* ---------- pausing (lock screen, sleep, full-screen apps, battery, user) ---------- */

    public void SetPause(string reason, bool on)
    {
        bool changed = on ? _pauseReasons.Add(reason) : _pauseReasons.Remove(reason);
        if (!changed) return;
        PushPause();
        StateChanged?.Invoke();
    }

    private void PushPause()
    {
        bool paused = _pauseReasons.Count > 0;
        string json = SceneConfig.ToJson(new { type = "pause", paused });
        foreach (WallpaperForm form in _forms) form.Post(json);
        Slideshow.SetExternalPause(paused);
    }

    private void UpdateTimers(AppSettings s)
    {
        bool watchFullscreen = _forms.Count > 0 && s.Behavior.PauseOnFullscreen;
        if (watchFullscreen) _fullscreenTimer.Start();
        else { _fullscreenTimer.Stop(); SetPause("fullscreen", false); }
        EvaluateBattery(s);
    }

    private void EvaluateBattery(AppSettings s)
    {
        bool onBattery = _forms.Count > 0 && s.Behavior.PauseOnBattery &&
                         SystemInformation.PowerStatus.PowerLineStatus == PowerLineStatus.Offline;
        SetPause("battery", onBattery);
    }

    private void OnFullscreenTick(object? sender, EventArgs e)
    {
        bool covered = _getSettings().Behavior.PauseOnFullscreen &&
                       _forms.Any(f => !f.IsDisposed && DesktopHost.IsForegroundFullscreen(f.TargetScreen.Bounds));
        SetPause("fullscreen", covered);
    }

    /* ---------- Windows events (these arrive on other threads) ---------- */

    private void OnDisplaySettingsChanged(object? sender, EventArgs e) =>
        _ui.BeginInvoke(new Action(() => { _displayTimer.Stop(); _displayTimer.Start(); }));

    private void OnDisplayTimer(object? sender, EventArgs e)
    {
        _displayTimer.Stop();
        if (_forms.Count > 0) _ = ApplyAsync(forceSlide: true);
    }

    private void OnSessionSwitch(object? sender, SessionSwitchEventArgs e)
    {
        if (e.Reason == SessionSwitchReason.SessionLock) _ui.BeginInvoke(new Action(() => SetPause("lock", true)));
        else if (e.Reason == SessionSwitchReason.SessionUnlock) _ui.BeginInvoke(new Action(() => SetPause("lock", false)));
    }

    private void OnPowerModeChanged(object? sender, PowerModeChangedEventArgs e)
    {
        _ui.BeginInvoke(new Action(() =>
        {
            if (e.Mode == PowerModes.Suspend) SetPause("sleep", true);
            else if (e.Mode == PowerModes.Resume) { SetPause("sleep", false); EvaluateBattery(_getSettings()); }
            else if (e.Mode == PowerModes.StatusChange) EvaluateBattery(_getSettings());
        }));
    }

    /* ---------- restoring the normal desktop ---------- */

    private static void RememberOriginalWallpaper()
    {
        try
        {
            if (File.Exists(AppPaths.OriginalWallpaperFile)) return;
            string? current = DesktopHost.GetCurrentWallpaperPath();
            if (string.IsNullOrEmpty(current)) return;
            Directory.CreateDirectory(AppPaths.DataDir);
            File.WriteAllText(AppPaths.OriginalWallpaperFile, current);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Log.Warn("Could not remember the original wallpaper: " + ex.Message);
        }
    }

    /// <summary>Stops everything and re-applies the wallpaper that was set before amir1200 first started. Returns false if unknown.</summary>
    public bool RestoreOriginal()
    {
        CloseForms();
        Slideshow.Stop();
        _effective = WallpaperMode.Off;
        UpdateTimers(_getSettings());
        try
        {
            if (!File.Exists(AppPaths.OriginalWallpaperFile)) return false;
            string path = File.ReadAllText(AppPaths.OriginalWallpaperFile).Trim();
            if (path.Length == 0 || !File.Exists(path)) return false;
            DesktopHost.ApplyWallpaperFile(path);
            return true;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Log.Warn("Restoring the wallpaper failed: " + ex.Message);
            return false;
        }
        finally
        {
            StateChanged?.Invoke();
        }
    }

    public void Dispose()
    {
        if (_disposed) return;
        _disposed = true;
        SystemEvents.DisplaySettingsChanged -= OnDisplaySettingsChanged;
        SystemEvents.SessionSwitch -= OnSessionSwitch;
        SystemEvents.PowerModeChanged -= OnPowerModeChanged;
        _fullscreenTimer.Stop();
        _displayTimer.Stop();
        Slideshow.SlideChanged -= OnSlide;
        CloseForms();
        Slideshow.Dispose();
    }
}
