using System;
using System.Drawing;
using System.Runtime.InteropServices;
using System.Text;

namespace Amir1200.App.Wallpaper;

internal enum AttachMethod
{
    None,
    /// <summary>Windows 11 24H2 and newer: desktop icons live inside Progman, so the window is a child of Progman placed just below the icon layer.</summary>
    ProgmanChild,
    /// <summary>Windows 10 and older Windows 11: window is a child of the WorkerW that sits behind the icon layer.</summary>
    LegacyWorkerW,
}

/// <summary>
/// Puts a window between the desktop wallpaper and the desktop icons.
/// This is the part that cannot be verified without a real Windows desktop, so it reports exactly what it did.
/// </summary>
internal static class DesktopHost
{
    private const int GWL_STYLE = -16;
    private const int GWL_EXSTYLE = -20;
    private const long WS_CHILD = 0x40000000L;
    private const long WS_POPUP = 0x80000000L;
    private const long WS_VISIBLE = 0x10000000L;
    private const long WS_EX_TOOLWINDOW = 0x00000080L;
    private const long WS_EX_APPWINDOW = 0x00040000L;
    private const long WS_EX_NOACTIVATE = 0x08000000L;
    private const uint SWP_NOACTIVATE = 0x0010;
    private const uint SWP_FRAMECHANGED = 0x0020;
    private const uint SWP_SHOWWINDOW = 0x0040;
    private const uint SPI_GETDESKWALLPAPER = 0x0073;
    private const uint SPI_SETDESKWALLPAPER = 0x0014;
    private const uint SPIF_UPDATEINIFILE = 0x01;
    private const uint SPIF_SENDCHANGE = 0x02;
    private static readonly IntPtr HWND_BOTTOM = new IntPtr(1);

    public static AttachMethod Attach(IntPtr hwnd, Rectangle screenBounds, out string detail)
    {
        detail = string.Empty;
        try
        {
            IntPtr progman = FindWindow("Progman", null);
            if (progman == IntPtr.Zero)
            {
                detail = "The desktop window (Progman) was not found.";
                return AttachMethod.None;
            }

            // Ask the shell to create the WorkerW layer that hosts the wallpaper.
            SendMessageTimeout(progman, 0x052C, IntPtr.Zero, IntPtr.Zero, 0x0000, 1000, out _);

            IntPtr parent;
            IntPtr insertAfter = IntPtr.Zero; // HWND_TOP within the parent
            AttachMethod method;

            IntPtr defViewInProgman = FindWindowEx(progman, IntPtr.Zero, "SHELLDLL_DefView", null);
            if (defViewInProgman != IntPtr.Zero)
            {
                parent = progman;
                insertAfter = defViewInProgman; // directly below the icon layer
                method = AttachMethod.ProgmanChild;
            }
            else
            {
                IntPtr workerW = IntPtr.Zero;
                EnumWindowsProc callback = (top, _) =>
                {
                    if (FindWindowEx(top, IntPtr.Zero, "SHELLDLL_DefView", null) != IntPtr.Zero)
                    {
                        workerW = FindWindowEx(IntPtr.Zero, top, "WorkerW", null);
                    }
                    return true;
                };
                EnumWindows(callback, IntPtr.Zero);
                GC.KeepAlive(callback);

                if (workerW == IntPtr.Zero)
                {
                    detail = "The WorkerW desktop layer was not found.";
                    return AttachMethod.None;
                }
                parent = workerW;
                method = AttachMethod.LegacyWorkerW;
            }

            long style = GetWindowLongPtr(hwnd, GWL_STYLE).ToInt64() & 0xFFFFFFFFL;
            style = (style & ~WS_POPUP) | WS_CHILD | WS_VISIBLE;
            SetWindowLongPtr(hwnd, GWL_STYLE, new IntPtr(style));

            long ex = GetWindowLongPtr(hwnd, GWL_EXSTYLE).ToInt64() & 0xFFFFFFFFL;
            ex = (ex | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE) & ~WS_EX_APPWINDOW;
            SetWindowLongPtr(hwnd, GWL_EXSTYLE, new IntPtr(ex));

            SetParent(hwnd, parent);

            var origin = new POINT { X = screenBounds.X, Y = screenBounds.Y };
            ScreenToClient(parent, ref origin);
            SetWindowPos(hwnd, insertAfter, origin.X, origin.Y, screenBounds.Width, screenBounds.Height,
                SWP_NOACTIVATE | SWP_SHOWWINDOW | SWP_FRAMECHANGED);

            if (GetParent(hwnd) != parent)
            {
                detail = "Windows did not accept the desktop attachment.";
                return AttachMethod.None;
            }

            detail = method == AttachMethod.ProgmanChild ? "Attached to Progman (Windows 11 24H2 layout)." : "Attached to WorkerW (classic layout).";
            return method;
        }
        catch (Exception ex) when (ex is DllNotFoundException or EntryPointNotFoundException or InvalidOperationException)
        {
            detail = "Desktop attachment failed: " + ex.Message;
            return AttachMethod.None;
        }
    }

    /// <summary>Fallback when attaching fails: a borderless window at the bottom of the z-order. Icons may be covered.</summary>
    public static void PlaceAtBottom(IntPtr hwnd, Rectangle bounds)
    {
        SetWindowPos(hwnd, HWND_BOTTOM, bounds.X, bounds.Y, bounds.Width, bounds.Height, SWP_NOACTIVATE | SWP_SHOWWINDOW);
    }

    /// <summary>True when the foreground window covers the whole monitor (a full-screen game or video).</summary>
    public static bool IsForegroundFullscreen(Rectangle monitor)
    {
        IntPtr fg = GetForegroundWindow();
        if (fg == IntPtr.Zero || fg == GetShellWindow() || fg == GetDesktopWindow()) return false;

        var cls = new StringBuilder(64);
        GetClassName(fg, cls, cls.Capacity);
        string name = cls.ToString();
        if (name is "Progman" or "WorkerW" or "Shell_TrayWnd") return false;

        if (!GetWindowRect(fg, out RECT r)) return false;
        return r.Left <= monitor.Left && r.Top <= monitor.Top && r.Right >= monitor.Right && r.Bottom >= monitor.Bottom;
    }

    public static string? GetCurrentWallpaperPath()
    {
        var sb = new StringBuilder(520);
        return SystemParametersInfo(SPI_GETDESKWALLPAPER, (uint)sb.Capacity, sb, 0) && sb.Length > 0 ? sb.ToString() : null;
    }

    public static void ApplyWallpaperFile(string path)
    {
        SystemParametersInfo(SPI_SETDESKWALLPAPER, 0, path, SPIF_UPDATEINIFILE | SPIF_SENDCHANGE);
    }

    private delegate bool EnumWindowsProc(IntPtr hWnd, IntPtr lParam);

    [StructLayout(LayoutKind.Sequential)]
    private struct POINT { public int X; public int Y; }

    [StructLayout(LayoutKind.Sequential)]
    private struct RECT { public int Left; public int Top; public int Right; public int Bottom; }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr FindWindow(string lpClassName, string? lpWindowName);

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr FindWindowEx(IntPtr parent, IntPtr childAfter, string? className, string? windowTitle);

    [DllImport("user32.dll", SetLastError = true)]
    private static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam, uint flags, uint timeout, out IntPtr result);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool EnumWindows(EnumWindowsProc callback, IntPtr lParam);

    [DllImport("user32.dll")]
    private static extern IntPtr SetParent(IntPtr child, IntPtr newParent);

    [DllImport("user32.dll")]
    private static extern IntPtr GetParent(IntPtr hWnd);

    [DllImport("user32.dll", EntryPoint = "GetWindowLongPtrW")]
    private static extern IntPtr GetWindowLongPtr(IntPtr hWnd, int index);

    [DllImport("user32.dll", EntryPoint = "SetWindowLongPtrW")]
    private static extern IntPtr SetWindowLongPtr(IntPtr hWnd, int index, IntPtr value);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SetWindowPos(IntPtr hWnd, IntPtr insertAfter, int x, int y, int cx, int cy, uint flags);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool ScreenToClient(IntPtr hWnd, ref POINT point);

    [DllImport("user32.dll")]
    private static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    private static extern IntPtr GetShellWindow();

    [DllImport("user32.dll")]
    private static extern IntPtr GetDesktopWindow();

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern int GetClassName(IntPtr hWnd, StringBuilder text, int maxCount);

    [DllImport("user32.dll")]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool GetWindowRect(IntPtr hWnd, out RECT rect);

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SystemParametersInfo(uint action, uint param, StringBuilder buffer, uint winIni);

    [DllImport("user32.dll", CharSet = CharSet.Unicode, SetLastError = true)]
    [return: MarshalAs(UnmanagedType.Bool)]
    private static extern bool SystemParametersInfo(uint action, uint param, string path, uint winIni);
}
