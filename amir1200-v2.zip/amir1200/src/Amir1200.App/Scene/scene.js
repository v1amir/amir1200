(() => {
  'use strict';
  const $ = (id) => document.getElementById(id);
  const stage = $('stage'), video = $('video'), gallery = $('gallery'), overlay = $('overlay');
  const slides = [$('slideA'), $('slideB')];
  const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isTop = window.parent === window;
  const hostBridge = isTop && window.chrome && window.chrome.webview ? window.chrome.webview : null;

  let cfg = null;
  let target = NaN;          // absolute release time, epoch milliseconds
  let timer = 0;
  let paused = false;
  let current = -1;          // index of the visible slide layer
  let slideToken = 0;
  let preloadRef = null;
  const hex = /^#[0-9a-fA-F]{6}$/;

  /* ---------- messaging ---------- */
  function send(msg) {
    try {
      if (hostBridge) hostBridge.postMessage(msg);
      else if (!isTop) window.parent.postMessage(Object.assign({ source: 'scene' }, msg), '*');
    } catch (e) { /* host may be shutting down */ }
  }
  if (hostBridge) hostBridge.addEventListener('message', (e) => handle(e.data));
  window.addEventListener('message', (e) => { if (!isTop && e.source === window.parent) handle(e.data); });

  function handle(m) {
    if (!m || typeof m !== 'object') return;
    switch (m.type) {
      case 'config': applyConfig(m.config || {}); break;
      case 'slide': showSlide(m); break;
      case 'pause': setPaused(!!m.paused); break;
      case 'video': videoCommand(m.cmd); break;
    }
  }

  /* ---------- config ---------- */
  function applyConfig(c) {
    cfg = c;
    stage.dataset.mode = c.mode || 'off';
    applyOverlay(c.overlay || {}, c.mode);
    applyCountdown(c.countdown || {});
    applyVideo(c);
    applyGallery(c);
    restartTicker();
  }

  function applyOverlay(o, mode) {
    const color = (v, d) => (typeof v === 'string' && hex.test(v) ? v : d);
    const s = overlay.style;
    s.setProperty('--pink', color(o.accentPink, '#ff2d95'));
    s.setProperty('--cyan', color(o.accentCyan, '#18f0ff'));
    s.setProperty('--text', color(o.textColor, '#ffffff'));
    s.setProperty('--glow', String(num(o.glow, 1, 0, 2)));
    s.setProperty('--scale', String(num(o.scale, 1, 0.4, 2.5)));
    s.setProperty('--opacity', String(num(o.opacity, 1, 0.1, 1)));
    s.setProperty('--ox', String(num(o.offsetXPercent, 0, -50, 50)));
    s.setProperty('--oy', String(num(o.offsetYPercent, 0, -50, 50)));
    overlay.dataset.preset = o.preset || 'cinematicCenter';
    overlay.dataset.pos = o.position || 'center';
    let show = o.visible !== false;
    if (mode === 'video') show = show && o.showOnVideo !== false;
    if (mode === 'gallery') show = show && o.showOnGallery !== false;
    overlay.hidden = !show;
  }

  function num(v, d, min, max) {
    const n = Number(v);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : d;
  }

  /* ---------- countdown ---------- */
  function applyCountdown(cd) {
    const valid = cd.valid !== false && Number.isFinite(Number(cd.targetEpochMs));
    target = valid ? Number(cd.targetEpochMs) : NaN;
    overlay.classList.toggle('invalid', !valid);
    $('finalTitle').textContent = cd.finalTitle || "IT'S TIME";
    $('finalSub').textContent = cd.finalSubtitle || '';
    resetDigits();
    render();
  }

  function resetDigits() {
    overlay.querySelectorAll('.digits').forEach((el) => { el.textContent = ''; el.dataset.value = ''; });
  }

  function setDigits(unit, text) {
    const el = overlay.querySelector('[data-unit="' + unit + '"] .digits');
    if (!el) return;
    const had = el.dataset.value !== '' && el.dataset.value !== undefined;
    if (el.children.length !== text.length) {
      el.textContent = '';
      for (let i = 0; i < text.length; i++) el.appendChild(document.createElement('span')).className = 'd';
    }
    for (let i = 0; i < text.length; i++) {
      const d = el.children[i];
      if (d.textContent !== text[i]) {
        d.textContent = text[i];
        if (had && !reducedMotion) { d.classList.remove('flip'); void d.offsetWidth; d.classList.add('flip'); }
      }
    }
    el.dataset.value = text;
  }

  function render() {
    if (!Number.isFinite(target)) { overlay.classList.remove('released'); return true; }
    const r = A1200.split(target - Date.now());
    overlay.classList.toggle('released', r.released);
    if (!r.released) {
      setDigits('days', A1200.pad(r.days, 2));
      setDigits('hours', A1200.pad(r.hours, 2));
      setDigits('minutes', A1200.pad(r.minutes, 2));
      setDigits('seconds', A1200.pad(r.seconds, 2));
    }
    return r.released;
  }

  function restartTicker() {
    clearTimeout(timer);
    timer = 0;
    if (paused || overlay.hidden || !Number.isFinite(target)) return;
    const loop = () => {
      const done = render();
      if (!done) timer = setTimeout(loop, A1200.msToNextSecond(Date.now()));
    };
    loop();
  }

  document.addEventListener('visibilitychange', () => { if (!document.hidden) restartTicker(); });

  /* ---------- video ---------- */
  function applyVideo(c) {
    const v = c.video || {};
    video.dataset.fit = v.fit || 'fill';
    const want = c.mode === 'video' && typeof v.url === 'string' && v.url;
    if (want) {
      if (video.dataset.src !== v.url) {
        video.dataset.src = v.url;
        video.src = v.url;
        video.load();
      }
      video.loop = v.loop !== false;
      video.muted = !!v.muted;
      video.volume = num(v.volume, 50, 0, 100) / 100;
      if (!paused) playVideo();
    } else if (video.dataset.src) {
      video.pause();
      video.removeAttribute('src');
      delete video.dataset.src;
      video.load(); // releases the decoder and file handle
    }
  }

  function playVideo() {
    const p = video.play();
    if (!p || !p.catch) return;
    p.catch((err) => {
      if (err && err.name === 'AbortError') return;
      if (err && err.name === 'NotAllowedError' && !video.muted) {
        video.muted = true; // browsers may refuse unmuted autoplay; fall back to muted playback
        send({ type: 'sceneWarning', kind: 'video', message: 'Sound was blocked by the browser engine, so the video plays muted.' });
        playVideo();
        return;
      }
      send({ type: 'sceneError', kind: 'video', message: String((err && err.message) || err) });
    });
  }

  function videoCommand(cmd) {
    if (!video.dataset.src) return;
    if (cmd === 'pause') video.pause();
    else if (cmd === 'play' && !paused) playVideo();
    else if (cmd === 'restart') { video.currentTime = 0; if (!paused) playVideo(); }
  }

  video.addEventListener('error', () => {
    if (!video.dataset.src) return;
    const code = video.error ? video.error.code : 0;
    const text = {
      1: 'Video loading was cancelled.',
      2: 'The video could not be read (file moved, locked, or on a disconnected drive).',
      3: 'The video could not be decoded. The file may be damaged.',
      4: 'This video format or codec is not supported. Try an H.264 MP4 or a WebM file.',
    }[code] || 'The video could not be played.';
    send({ type: 'sceneError', kind: 'video', code, message: text });
  });

  /* ---------- gallery ---------- */
  function applyGallery(c) {
    const g = c.gallery || {};
    gallery.dataset.fit = g.fit || 'fill';
    gallery.classList.toggle('kb', g.kenBurns !== false && !reducedMotion);
    const xf = num(g.crossfadeSeconds, 1.2, 0, 5);
    stage.style.setProperty('--xfade', xf + 's');
    stage.style.setProperty('--kbdur', num(g.intervalSeconds, 15, 3, 3600) + xf + 1 + 's');
    if (c.mode !== 'gallery') clearSlides();
  }

  function clearSlides() {
    slideToken++;
    current = -1;
    preloadRef = null;
    slides.forEach((s) => {
      s.classList.remove('on');
      s.querySelector('img').removeAttribute('src');
      s.querySelector('.bd').style.backgroundImage = '';
    });
  }

  async function showSlide(m) {
    if (!m.url || !cfg || cfg.mode !== 'gallery') return;
    const token = ++slideToken;
    const idx = current === 0 ? 1 : 0;
    const el = slides[idx];
    const img = el.querySelector('img');
    try {
      img.src = m.url;
      await img.decode();
    } catch (e) {
      if (token === slideToken) send({ type: 'sceneError', kind: 'image', url: m.url, message: 'This image could not be loaded.' });
      return;
    }
    if (token !== slideToken) return; // a newer slide was requested while decoding
    el.querySelector('.bd').style.backgroundImage = 'url("' + m.url.replace(/"/g, '%22') + '")';
    el.style.setProperty('--kbx', (Math.random() < 0.5 ? -1 : 1) * (0.6 + Math.random() * 1.2) + '%');
    el.style.setProperty('--kby', (Math.random() < 0.5 ? -1 : 1) * (0.4 + Math.random() * 0.9) + '%');
    const old = current;
    el.classList.add('on');
    if (old >= 0) {
      slides[old].classList.remove('on');
      const oldImg = slides[old].querySelector('img');
      const wait = (parseFloat(stage.style.getPropertyValue('--xfade')) || 1.2) * 1000 + 300;
      setTimeout(() => { if (!slides[old].classList.contains('on')) oldImg.removeAttribute('src'); }, wait);
    }
    current = idx;
    if (m.preload) { preloadRef = new Image(); preloadRef.decoding = 'async'; preloadRef.src = m.preload; }
    send({ type: 'slideShown', url: m.url });
  }

  /* ---------- pause (lock screen, sleep, fullscreen app, user) ---------- */
  function setPaused(p) {
    paused = p;
    stage.classList.toggle('paused', p);
    if (p) {
      video.pause();
      clearTimeout(timer);
    } else {
      if (cfg && cfg.mode === 'video' && video.dataset.src) playVideo();
      restartTicker(); // recomputes from the clock, so sleep/resume is always correct
    }
  }

  window.__scene = { handle, state: () => ({ cfg, target, paused, current }) };
  send({ type: 'sceneReady' });
})();
