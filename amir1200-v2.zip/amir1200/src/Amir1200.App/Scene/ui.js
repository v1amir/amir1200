(() => {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
  const bridge = window.chrome && window.chrome.webview;
  const post = (msg) => { try { if (bridge) bridge.postMessage(msg); } catch (e) { /* host closing */ } };

  let S = null;                 // editable settings copy
  let scene = null;             // scene config computed by the host (target time, media urls)
  let info = { images: [], videoName: '', status: {}, version: '', settingsPath: '' };
  let page = 'dashboard';
  let frame = null, frameReady = false, lastSlide = '';
  let saveTimer = 0;

  /* ---------- helpers ---------- */
  const getPath = (p) => p.split('.').reduce((o, k) => (o == null ? o : o[k]), S);
  function setPath(p, v) {
    const ks = p.split('.'); const last = ks.pop();
    const o = ks.reduce((a, k) => a[k], S);
    o[last] = v;
  }
  const fmt = (v) => String(Number(Number(v).toFixed(2)));
  function readInput(el) {
    if (el.type === 'checkbox') return el.checked;
    if (el.type === 'range' || el.type === 'number') return Number(el.value);
    return el.value;
  }

  function toast(level, text, ms) {
    const box = $('#toasts');
    if ($$('.toast', box).some((t) => t.textContent === text)) return;
    const t = document.createElement('div');
    t.className = 'toast ' + level;
    t.textContent = text;
    box.appendChild(t);
    setTimeout(() => t.remove(), ms || (level === 'error' ? 9000 : 4500));
  }

  /* ---------- host messages ---------- */
  if (bridge) bridge.addEventListener('message', (e) => onHost(e.data));

  function onHost(m) {
    if (!m || typeof m !== 'object') return;
    switch (m.type) {
      case 'state':
        S = m.settings; scene = m.scene;
        info = Object.assign(info, { images: m.images || [], videoName: m.videoName || '', videoError: m.videoError || null,
          status: m.status || {}, version: m.version || '', settingsPath: m.settingsPath || '' });
        renderAll();
        break;
      case 'scene':
        scene = m.scene; info.status = m.status || info.status; info.videoError = m.videoError || null;
        renderStatus(); renderVideo(); renderCountdownInfo(); pushPreview();
        break;
      case 'toast': toast(m.level || 'info', m.text || ''); break;
      case 'slide':
        lastSlide = m.url || '';
        if (frame && frameReady && previewMode() === 'gallery') frame.contentWindow.postMessage({ type: 'slide', url: m.url, preload: m.preload }, '*');
        break;
      case 'slideshowState': $('#btnToggle').textContent = m.paused ? 'Resume' : 'Pause'; break;
    }
  }

  window.addEventListener('message', (e) => {
    if (!frame || e.source !== frame.contentWindow || !e.data) return;
    if (e.data.type === 'sceneReady') { frameReady = true; pushPreview(); }
    else if (e.data.type === 'sceneError' && e.data.kind === 'video' && page === 'video') toast('error', e.data.message);
  });

  /* ---------- preview ---------- */
  function previewMode() {
    if (!scene) return 'countdownOnly';
    if (page === 'dashboard') return scene.mode === 'off' ? 'countdownOnly' : scene.mode;
    if (page === 'video') return scene.video && scene.video.url ? 'video' : 'countdownOnly';
    if (page === 'gallery') return 'gallery';
    return 'countdownOnly';
  }

  function mountPreview() {
    const box = $('.page.active [data-preview]');
    if (frame && frame.parentElement === box) return;
    if (frame) { frame.remove(); frame = null; }
    frameReady = false;
    if (!box) return;
    frame = document.createElement('iframe');
    frame.title = 'Wallpaper preview';
    frame.setAttribute('tabindex', '-1');
    frame.src = 'scene.html';
    box.appendChild(frame);
  }

  function pushPreview() {
    if (!frame || !frameReady || !scene || !S) return;
    const g = S.gallery;
    const cfg = {
      mode: previewMode(),
      countdown: scene.countdown,
      overlay: S.overlay,
      video: { fit: S.video.fit, loop: S.video.loop, url: scene.video && scene.video.url, muted: true, volume: 0 },
      gallery: { fit: g.fit, kenBurns: g.kenBurns, crossfadeSeconds: g.crossfadeSeconds, intervalSeconds: g.intervalSeconds },
    };
    frame.contentWindow.postMessage({ type: 'config', config: cfg }, '*');
    if (cfg.mode === 'gallery') {
      const first = info.images.find((i) => i.included && !i.missing);
      const url = lastSlide || (first && first.url);
      if (url) frame.contentWindow.postMessage({ type: 'slide', url }, '*');
    }
  }

  /* ---------- navigation ---------- */
  function showPage(p) {
    page = p;
    $$('.nav').forEach((b) => b.classList.toggle('active', b.dataset.page === p));
    $$('.page').forEach((s) => s.classList.toggle('active', s.id === 'page-' + p));
    mountPreview(); pushPreview();
  }
  $$('.nav').forEach((b) => b.addEventListener('click', () => showPage(b.dataset.page)));

  /* ---------- rendering ---------- */
  function renderAll() {
    $$('[data-bind]').forEach((el) => {
      const v = getPath(el.dataset.bind);
      if (el.type === 'checkbox') el.checked = !!v; else el.value = v;
    });
    $$('output[data-for]').forEach((o) => { o.textContent = fmt(getPath(o.dataset.for)); });
    renderStatus(); renderVideo(); renderGallery(); renderCountdown(); renderSettings();
    mountPreview(); pushPreview();
  }

  function renderStatus() {
    const st = info.status || {};
    $$('.mode').forEach((b) => b.classList.toggle('active', b.dataset.mode === st.mode));
    const rail = $('#railStatus');
    rail.className = 'railStatus ' + (st.level || '');
    $('#railStatusText').textContent = st.short || 'Idle';
    $('#statusLine').textContent = st.text || '';
    const included = (info.images || []).filter((i) => i.included && !i.missing).length;
    $('#modeVideoHint').textContent = S && S.video.path ? (info.videoName || 'Your video') : 'Choose a video first';
    $('#modeGalleryHint').textContent = included ? included + (included === 1 ? ' image' : ' images') : 'Add screenshots first';
  }

  function renderVideo() {
    $('#videoPath').textContent = S && S.video.path ? S.video.path : 'No video selected.';
    const err = $('#videoError');
    err.hidden = !info.videoError;
    err.textContent = info.videoError || '';
  }

  function renderGallery() {
    const grid = $('#grid');
    grid.textContent = '';
    const imgs = info.images || [];
    $('#galleryCount').textContent = imgs.length + (imgs.length === 1 ? ' image' : ' images');
    $('#galleryEmpty').hidden = imgs.length > 0;
    let dragFrom = -1;
    imgs.forEach((im, idx) => {
      const card = document.createElement('div');
      card.className = 'card' + (im.included ? '' : ' off');
      card.draggable = true;
      const img = document.createElement('img');
      img.alt = ''; img.loading = 'lazy'; img.decoding = 'async'; img.draggable = false;
      if (!im.missing) img.src = im.url;
      card.appendChild(img);
      if (im.missing) { const m = document.createElement('div'); m.className = 'missing'; m.textContent = 'File not found'; card.appendChild(m); }
      const x = document.createElement('button');
      x.className = 'x'; x.textContent = '×'; x.title = 'Remove from gallery'; x.setAttribute('aria-label', 'Remove ' + im.name);
      x.addEventListener('click', () => post({ type: 'removeImage', path: im.path }));
      card.appendChild(x);
      const meta = document.createElement('div'); meta.className = 'meta';
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!im.included;
      cb.title = 'Include in slideshow'; cb.setAttribute('aria-label', 'Include ' + im.name);
      cb.addEventListener('change', () => post({ type: 'setIncluded', path: im.path, included: cb.checked }));
      const name = document.createElement('span'); name.textContent = im.name; name.title = im.path;
      meta.append(cb, name); card.appendChild(meta);
      card.addEventListener('dragstart', (e) => { dragFrom = idx; card.classList.add('dragging'); e.dataTransfer.effectAllowed = 'move'; e.dataTransfer.setData('text/plain', String(idx)); });
      card.addEventListener('dragend', () => card.classList.remove('dragging'));
      card.addEventListener('dragover', (e) => { e.preventDefault(); card.classList.add('over'); });
      card.addEventListener('dragleave', () => card.classList.remove('over'));
      card.addEventListener('drop', (e) => {
        e.preventDefault(); card.classList.remove('over');
        if (dragFrom >= 0 && dragFrom !== idx) post({ type: 'moveImage', from: dragFrom, to: idx });
      });
      grid.appendChild(card);
    });
  }

  function renderCountdown() {
    const c = S.countdown;
    $('#targetInput').value = c.targetLocal;
    $('#finalTitle').value = c.finalTitle; $('#finalSub').value = c.finalSubtitle;
    const sel = $('#tzSelect');
    if (!sel.dataset.ready) {
      sel.dataset.ready = '1';
      const add = (v, t) => { const o = document.createElement('option'); o.value = v; o.textContent = t; sel.appendChild(o); };
      add('local', "My PC's time zone");
      let zones = [];
      try { zones = Intl.supportedValuesOf('timeZone'); } catch (e) { zones = ['UTC']; }
      zones.forEach((z) => add(z, z.replace(/_/g, ' ')));
    }
    if (!Array.from(sel.options).some((o) => o.value === c.timeZoneId)) {
      const o = document.createElement('option'); o.value = c.timeZoneId; o.textContent = c.timeZoneId; sel.appendChild(o);
    }
    sel.value = c.timeZoneId;
    $$('.preset').forEach((b) => b.classList.toggle('active', b.dataset.preset === S.overlay.preset));
    renderCountdownInfo();
  }

  function renderCountdownInfo() {
    if (!scene || !S) return;
    const cd = scene.countdown || {};
    const err = $('#targetError');
    err.hidden = !cd.error; err.textContent = cd.error || '';
    let line = S.countdown.releaseNote || '';
    if (cd.valid && Number.isFinite(cd.targetEpochMs)) line += (line ? ' ' : '') + 'On this PC that is ' + new Date(cd.targetEpochMs).toLocaleString() + '.';
    $('#targetInfo').textContent = line;
  }

  function renderSettings() {
    $('#aboutLine').textContent = 'amir1200 ' + (info.version || '') + (info.settingsPath ? ' - settings file: ' + info.settingsPath : '');
  }

  /* ---------- editing ---------- */
  function queueSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => post({ type: 'save', settings: S }), 250);
  }

  document.addEventListener('input', (e) => {
    const el = e.target;
    if (!S || !el.dataset || !el.dataset.bind) return;
    setPath(el.dataset.bind, readInput(el));
    $$('output[data-for="' + el.dataset.bind + '"]').forEach((o) => { o.textContent = fmt(getPath(el.dataset.bind)); });
    if (el.dataset.bind === 'overlay.preset') renderCountdown();
    queueSave(); pushPreview();
  });

  $('#targetInput').addEventListener('change', (e) => { if (e.target.value) { S.countdown.targetLocal = e.target.value; queueSave(); } });
  $('#tzSelect').addEventListener('change', (e) => { S.countdown.timeZoneId = e.target.value; queueSave(); });
  $('#finalTitle').addEventListener('input', (e) => { S.countdown.finalTitle = e.target.value; queueSave(); });
  $('#finalSub').addEventListener('input', (e) => { S.countdown.finalSubtitle = e.target.value; queueSave(); });
  $$('.preset').forEach((b) => b.addEventListener('click', () => {
    S.overlay.preset = b.dataset.preset; renderCountdown(); queueSave(); pushPreview();
  }));

  /* ---------- actions ---------- */
  function requestMode(mode) {
    if (mode === 'video' && !(S && S.video.path)) { toast('info', 'Choose a video first.'); showPage('video'); return; }
    if (mode === 'gallery' && !info.images.some((i) => i.included && !i.missing)) { toast('info', 'Add some screenshots first.'); showPage('gallery'); return; }
    post({ type: 'setMode', mode });
  }
  $$('.mode').forEach((b) => b.addEventListener('click', () => requestMode(b.dataset.mode)));

  $('#btnPickVideo').addEventListener('click', () => post({ type: 'pickVideo' }));
  $('#btnStartVideo').addEventListener('click', () => requestMode('video'));
  $('#btnStopVideo').addEventListener('click', () => post({ type: 'setMode', mode: 'off' }));
  $('#btnVideoPause').addEventListener('click', () => post({ type: 'videoCmd', cmd: 'pause' }));
  $('#btnVideoPlay').addEventListener('click', () => post({ type: 'videoCmd', cmd: 'play' }));
  $('#btnVideoRestart').addEventListener('click', () => post({ type: 'videoCmd', cmd: 'restart' }));

  $('#btnAddImages').addEventListener('click', () => post({ type: 'addImages' }));
  $('#btnAddFolder').addEventListener('click', () => post({ type: 'addFolder' }));
  $('#btnClearGallery').addEventListener('click', () => {
    if (info.images.length && confirm('Remove all images from the gallery? Your files are not deleted.')) post({ type: 'clearGallery' });
  });
  $('#btnPrev').addEventListener('click', () => post({ type: 'slideshow', cmd: 'prev' }));
  $('#btnNext').addEventListener('click', () => post({ type: 'slideshow', cmd: 'next' }));
  $('#btnToggle').addEventListener('click', () => post({ type: 'slideshow', cmd: 'toggle' }));
  $('#btnStartGallery').addEventListener('click', () => requestMode('gallery'));

  $('#btnRestore').addEventListener('click', () => post({ type: 'restoreWallpaper' }));
  $('#btnLogs').addEventListener('click', () => post({ type: 'openLogs' }));
  $('#btnReset').addEventListener('click', () => { if (confirm('Reset every amir1200 setting to its default? Your files are not deleted.')) post({ type: 'resetSettings' }); });

  // Test hook (also lets the host push messages in a plain browser).
  window.__ui = { onHost, state: () => ({ S, scene, info, page }) };
  post({ type: 'ready' });
})();
