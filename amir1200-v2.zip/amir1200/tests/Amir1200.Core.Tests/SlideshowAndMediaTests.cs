using Amir1200.Core;
using Xunit;

namespace Amir1200.Core.Tests;

public class SlideshowTests
{
    private static SlideshowEngine Make(bool shuffle, bool repeat, params string[] items)
    {
        var e = new SlideshowEngine(seed: 42) { Shuffle = shuffle, Repeat = repeat };
        e.SetItems(items);
        return e;
    }

    [Fact]
    public void Sequential_goes_in_order_and_wraps_when_repeating()
    {
        var e = Make(false, true, "a", "b", "c");
        Assert.Equal("a", e.Current);
        Assert.Equal("b", e.MoveNext());
        Assert.Equal("c", e.MoveNext());
        Assert.Equal("a", e.MoveNext());
    }

    [Fact]
    public void Non_repeating_show_ends()
    {
        var e = Make(false, false, "a", "b");
        Assert.Equal("b", e.MoveNext());
        Assert.Null(e.MoveNext());
        Assert.True(e.Finished);
        Assert.Equal("b", e.Current);
    }

    [Fact]
    public void Previous_wraps_only_when_repeating()
    {
        var rep = Make(false, true, "a", "b", "c");
        Assert.Equal("c", rep.MovePrevious());
        var once = Make(false, false, "a", "b", "c");
        Assert.Equal("a", once.MovePrevious());
    }

    [Fact]
    public void Shuffle_shows_every_image_once_per_cycle()
    {
        var items = Enumerable.Range(0, 20).Select(i => "img" + i).ToArray();
        var e = Make(true, true, items);
        var seen = new List<string> { e.Current! };
        for (int i = 0; i < 19; i++) seen.Add(e.MoveNext()!);
        Assert.Equal(items.OrderBy(x => x), seen.OrderBy(x => x));
    }

    [Fact]
    public void Shuffle_never_repeats_same_image_across_cycles()
    {
        var e = Make(true, true, "a", "b");
        string? previous = e.Current;
        for (int i = 0; i < 50; i++)
        {
            var next = e.MoveNext();
            Assert.NotEqual(previous, next);
            previous = next;
        }
    }

    [Fact]
    public void Empty_list_is_safe()
    {
        var e = Make(false, true);
        Assert.Null(e.Current);
        Assert.Null(e.MoveNext());
        Assert.Null(e.MovePrevious());
        Assert.Null(e.PeekNext());
    }

    [Fact]
    public void Single_image_repeats_itself()
    {
        var e = Make(true, true, "only");
        Assert.Equal("only", e.MoveNext());
        Assert.Equal("only", e.Current);
    }

    [Fact]
    public void Updating_items_keeps_current_image_and_sequential_order()
    {
        var e = Make(false, true, "a", "b", "c");
        e.MoveNext(); // b
        e.SetItems(new[] { "a", "b", "c", "d" });
        Assert.Equal("b", e.Current);
        Assert.Equal("c", e.MoveNext());
    }

    [Fact]
    public void Removing_current_image_falls_back_to_start()
    {
        var e = Make(false, true, "a", "b", "c");
        e.MoveNext();
        e.SetItems(new[] { "a", "c" });
        Assert.Equal("a", e.Current);
    }

    [Fact]
    public void PeekNext_returns_following_image_without_moving()
    {
        var e = Make(false, true, "a", "b");
        Assert.Equal("b", e.PeekNext());
        Assert.Equal("a", e.Current);
        e.MoveNext();
        Assert.Equal("a", e.PeekNext());
    }
}

public class MediaTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "amir1200-media-" + Guid.NewGuid().ToString("N"));

    public MediaTests() => Directory.CreateDirectory(_dir);
    public void Dispose() => Directory.Delete(_dir, true);

    [Theory]
    [InlineData("a.MP4", true)]
    [InlineData("a.webm", true)]
    [InlineData("a.mov", true)]
    [InlineData("a.avi", false)]
    [InlineData("a", false)]
    [InlineData("", false)]
    public void Video_extension_check(string path, bool expected) => Assert.Equal(expected, MediaFiles.IsVideo(path));

    [Theory]
    [InlineData("a.JPG", true)]
    [InlineData("a.jpeg", true)]
    [InlineData("a.png", true)]
    [InlineData("a.webp", true)]
    [InlineData("a.bmp", true)]
    [InlineData("a.gif", false)]
    [InlineData("a.txt", false)]
    public void Image_extension_check(string path, bool expected) => Assert.Equal(expected, MediaFiles.IsImage(path));

    [Fact]
    public void Missing_video_gives_friendly_error()
    {
        var err = MediaFiles.ValidateVideo(Path.Combine(_dir, "gone.mp4"));
        Assert.NotNull(err);
        Assert.Contains("moved or deleted", err);
    }

    [Fact]
    public void Unsupported_video_format_gives_friendly_error()
    {
        var p = Path.Combine(_dir, "clip.avi");
        File.WriteAllText(p, "x");
        Assert.Contains("not supported", MediaFiles.ValidateVideo(p));
    }

    [Fact]
    public void Existing_video_passes_and_null_path_is_reported()
    {
        var p = Path.Combine(_dir, "clip.mp4");
        File.WriteAllText(p, "x");
        Assert.Null(MediaFiles.ValidateVideo(p));
        Assert.NotNull(MediaFiles.ValidateVideo(null));
    }

    [Fact]
    public void Folder_enumeration_filters_sorts_and_can_recurse()
    {
        Directory.CreateDirectory(Path.Combine(_dir, "sub"));
        foreach (var f in new[] { "b.png", "a.JPG", "notes.txt", Path.Combine("sub", "c.webp") })
            File.WriteAllText(Path.Combine(_dir, f), "x");

        var flat = MediaFiles.EnumerateImages(_dir, false).Select(Path.GetFileName).ToList();
        Assert.Equal(new[] { "a.JPG", "b.png" }, flat);
        Assert.Equal(3, MediaFiles.EnumerateImages(_dir, true).Count);
        Assert.Empty(MediaFiles.EnumerateImages(Path.Combine(_dir, "missing"), true));
    }

    [Fact]
    public void Gallery_add_skips_duplicates_and_unsupported_files()
    {
        var g = new GallerySettings();
        Assert.Equal(2, GalleryOps.AddRange(g, new[] { @"C:\a.jpg", @"C:\A.JPG", @"C:\b.png", @"C:\c.gif" }));
        Assert.Equal(0, GalleryOps.AddRange(g, new[] { @"C:\a.jpg" }));
        Assert.Equal(2, g.Images.Count);
    }

    [Fact]
    public void Gallery_remove_include_move_and_included_paths()
    {
        var g = new GallerySettings();
        GalleryOps.AddRange(g, new[] { "a.jpg", "b.jpg", "c.jpg" });
        GalleryOps.SetIncluded(g, "b.jpg", false);
        Assert.Equal(new[] { "a.jpg", "c.jpg" }, GalleryOps.IncludedPaths(g));

        Assert.True(GalleryOps.Move(g, 0, 2));
        Assert.Equal(new[] { "b.jpg", "c.jpg", "a.jpg" }, g.Images.Select(i => i.Path));
        Assert.False(GalleryOps.Move(g, 5, 0));

        Assert.True(GalleryOps.Remove(g, "C.JPG"));
        Assert.False(GalleryOps.Remove(g, "nope.jpg"));
        Assert.Equal(2, g.Images.Count);
    }
}
