using Amir1200.Core;
using Xunit;

namespace Amir1200.Core.Tests;

public class CountdownTests
{
    [Fact]
    public void Utc_zone_gives_exact_instant()
    {
        Assert.True(CountdownCalculator.TryGetTargetInstant("2026-11-19T00:00", "UTC", out var t, out var err));
        Assert.Null(err);
        Assert.Equal(new DateTimeOffset(2026, 11, 19, 0, 0, 0, TimeSpan.Zero), t);
    }

    [Fact]
    public void Splits_into_days_hours_minutes_seconds()
    {
        var target = new DateTimeOffset(2026, 11, 19, 0, 0, 0, TimeSpan.Zero);
        var now = target - new TimeSpan(10, 3, 4, 5);
        var r = CountdownCalculator.Compute(target, now);
        Assert.Equal((10, 3, 4, 5), (r.Days, r.Hours, r.Minutes, r.Seconds));
        Assert.False(r.IsReleased);
    }

    [Fact]
    public void Partial_second_rounds_up_and_zero_means_released()
    {
        var target = new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);
        Assert.Equal(1, CountdownCalculator.Compute(target, target.AddMilliseconds(-400)).TotalSeconds);
        Assert.True(CountdownCalculator.Compute(target, target).IsReleased);
    }

    [Fact]
    public void Never_negative_after_target()
    {
        var target = new DateTimeOffset(2026, 1, 1, 0, 0, 0, TimeSpan.Zero);
        var r = CountdownCalculator.Compute(target, target.AddDays(30));
        Assert.True(r.IsReleased);
        Assert.Equal(0, r.TotalSeconds);
        Assert.Equal((0, 0, 0, 0), (r.Days, r.Hours, r.Minutes, r.Seconds));
    }

    [Theory]
    [InlineData("not a date")]
    [InlineData("2026-13-40T99:99")]
    [InlineData("")]
    [InlineData(null)]
    [InlineData("1999-01-01T00:00")]
    public void Invalid_dates_are_rejected_with_message(string? value)
    {
        Assert.False(CountdownCalculator.TryGetTargetInstant(value, "UTC", out _, out var err));
        Assert.False(string.IsNullOrWhiteSpace(err));
    }

    [Fact]
    public void Unknown_time_zone_is_rejected()
    {
        Assert.False(CountdownCalculator.TryGetTargetInstant("2026-11-19T00:00", "Mars/Olympus", out _, out var err));
        Assert.Contains("not found", err);
    }

    [Fact]
    public void Local_zone_works()
    {
        Assert.True(CountdownCalculator.TryGetTargetInstant("2026-11-19T00:00", "local", out var t, out _));
        Assert.Equal(TimeZoneInfo.Local.GetUtcOffset(new DateTime(2026, 11, 19)), t.Offset);
    }

    [Fact]
    public void Dst_gap_time_moves_forward_instead_of_failing()
    {
        TimeZoneInfo tz;
        try { tz = TimeZoneInfo.FindSystemTimeZoneById("America/New_York"); }
        catch (TimeZoneNotFoundException) { return; } // zone data unavailable on this machine
        // 2026-03-08 02:30 does not exist in New York (clocks jump 02:00 -> 03:00)
        Assert.True(CountdownCalculator.TryGetTargetInstant("2026-03-08T02:30", "America/New_York", out var t, out _));
        Assert.Equal(TimeSpan.FromHours(-4), t.Offset);
    }
}

public class SettingsTests : IDisposable
{
    private readonly string _dir = Path.Combine(Path.GetTempPath(), "amir1200-tests-" + Guid.NewGuid().ToString("N"));

    public void Dispose()
    {
        if (Directory.Exists(_dir)) Directory.Delete(_dir, true);
    }

    [Fact]
    public void Missing_file_gives_defaults()
    {
        var s = new SettingsStore(Path.Combine(_dir, "settings.json")).Load(out var warning);
        Assert.Null(warning);
        Assert.Equal(WallpaperMode.Off, s.Mode);
        Assert.Equal("2026-11-19T00:00", s.Countdown.TargetLocal);
        Assert.Equal(15, s.Gallery.IntervalSeconds);
    }

    [Fact]
    public void Round_trip_preserves_values()
    {
        var store = new SettingsStore(Path.Combine(_dir, "settings.json"));
        var s = new AppSettings { Mode = WallpaperMode.Gallery };
        s.Overlay.Preset = OverlayPreset.ViceCitySunset;
        s.Gallery.Images.Add(new GalleryImage { Path = @"C:\pics\a.jpg", Included = false });
        store.Save(s);

        var back = store.Load(out var warning);
        Assert.Null(warning);
        Assert.Equal(WallpaperMode.Gallery, back.Mode);
        Assert.Equal(OverlayPreset.ViceCitySunset, back.Overlay.Preset);
        Assert.False(back.Gallery.Images[0].Included);
        Assert.False(File.Exists(store.FilePath + ".tmp"));
    }

    [Fact]
    public void Corrupt_file_is_backed_up_and_defaults_returned()
    {
        Directory.CreateDirectory(_dir);
        var path = Path.Combine(_dir, "settings.json");
        File.WriteAllText(path, "{ this is not json");
        var s = new SettingsStore(path).Load(out var warning);
        Assert.NotNull(warning);
        Assert.Equal(WallpaperMode.Off, s.Mode);
        Assert.Single(Directory.GetFiles(_dir, "settings.json.corrupt-*"));
    }

    [Fact]
    public void Out_of_range_values_are_clamped()
    {
        var s = new AppSettings();
        s.Overlay.Scale = 99;
        s.Overlay.Opacity = double.NaN;
        s.Overlay.TextColor = "red; background:url(x)";
        s.Video.Volume = 500;
        s.Gallery.IntervalSeconds = 0;
        SettingsValidator.Normalize(s);
        Assert.Equal(2.5, s.Overlay.Scale);
        Assert.Equal(0.1, s.Overlay.Opacity);
        Assert.Equal("#ffffff", s.Overlay.TextColor);
        Assert.Equal(100, s.Video.Volume);
        Assert.Equal(3, s.Gallery.IntervalSeconds);
    }

    [Fact]
    public void Null_sections_from_hand_edited_file_are_repaired()
    {
        Directory.CreateDirectory(_dir);
        var path = Path.Combine(_dir, "settings.json");
        File.WriteAllText(path, "{ \"overlay\": null, \"gallery\": { \"images\": null } }");
        var s = new SettingsStore(path).Load(out var warning);
        Assert.Null(warning);
        Assert.NotNull(s.Overlay);
        Assert.NotNull(s.Gallery.Images);
    }
}
